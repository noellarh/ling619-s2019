#This is a tutorial for the concepts covered in Chapter 5: Data Transformation in the book R FOR DATA SCIENCE by Garrett Grolemund and Hadley Wickham. This tutorial covers 5.1-5.4. Noella Handley made this tutorial. 
library(tidyverse)

#Set your working directory to wherever you stored the file "suicide-rates-overview-1985-to-2016" 
setwd("~/Desktop/Spring 2019/Data Science/619-Data-Transformation-Part-1")
suicide.stats <- read.csv("who_suicide_statistics.csv", header = TRUE)
view(suicide.stats)

# filter - subset observations based on their values
# by country
filter(suicide.stats, country == "United States of America")

# by gender
filter(suicide.stats, sex == "female")

# suicides in a country with a population less than 1 million
filter(suicide.stats, population < 1000000)

#suicides in females aged 15-24 years
filter(suicide.stats, sex == "female", age == "15-24 years")

#save that filter
young.women <- filter(suicide.stats, sex == "female", age == "15-24 years")

#let's make other filters with the operations mentioned in 5.2.2-5.2.4

#arranging rows - change the order of rows in the table
arrange(suicide.stats, country, sex, age, suicides_no)

#descending rows
arrange(suicide.stats, desc(suicides_no))


#select - rapidly zoom in on a useful subset using operations based on the names of the variables

#select columns by name
select(suicide.stats, sex, age, suicides_no)

#select a range of columns
select(suicide.stats, year:suicides_no)

#select all columns except a specific one
select(suicide.stats, -(population))

# let's do these together

#rename a variable 


# everything ()
